from ccdgl import *
from atomic_radius import *
from pyplasm import *

def myprint (string):
    print "\n" + string + " ->", eval(string)

atom_color = {
    'H': Color4f([0.8, 0.8, 0.8, 1.0]), # ligth gray
    'C': Color4f([0.3, 0.3, 0.3, 1.0]), # dark gray (quite black)
    'N': BLUE,
    'O': RED,
    'F': Color4f([0.0, 0.75, 1.0, 1.0]), # ligth blue
    'P': ORANGE,
    'S': YELLOW,
    'Cl': GREEN,
    'K': Color4f([200./255, 162./255, 200./255, 1.0]) # lilac
}

residueTopology = {'': '',
 'ALA': [[1, 2], [2, 3], [3, 4], [2, 5]],
 'ARG': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [7, 8], [8, 9], [9, 10], [9, 11]],
 'ASN': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [6, 8]],
 'ASP': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [6, 8]],
 'CYS': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6]],
 'GLN': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [7, 8], [7, 9]],
 'GLU': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [7, 8], [7, 9]],
 'GLY': [[1, 2], [2, 3], [3, 4]],
 'HIS': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [6, 8], [7, 9], [9, 10], [8, 10]],
 'ILE': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [5, 7], [7, 8]],
 'LEU': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [6, 8]],
 'LYS': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [7, 8], [8, 9]],
 'MET': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [7, 8]],
 'PHE': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [6, 8], [7, 9], [8, 10], [9, 11], [10, 11]],
 'PRO': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [7, 1]],
 'SER': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6]],
 'THR': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [5, 7]],
 'TRP': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [6, 8], [7, 9], [9, 10], [8, 10], [8, 11], [10, 12], [11, 13], [12, 14], [13, 14]],
 'TYR': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [6, 7], [6, 8], [7, 9], [8, 10], [9, 11], [10, 11], [11, 12]],
 'VAL': [[1, 2], [2, 3], [3, 4], [2, 5], [5, 6], [5, 7]]
 }

unitSphere = Batch.openObj("sphere18x27.obj")[0]
unitCylinder = Batch.openObj("cylinder4x27.obj")[0]        


def myPDBParser (filename):
    """ To parse a PDB-CCD file looking for structure information.
    
    Return a list of Bio.PDB objects of type residue. Normally this list is a singleton,
    that has the molecule CCD code as residue ID.
    """
    parser=PDBParser()
    structure=parser.get_structure('molecule', filename)
    chains = []
    for model in structure:
        for chain in model:
            residues = []
            for residue in chain:
                residues += [residue]
            chains += [residues]
    return chains


def viewStructure(nodes,atom_types,arcs,viewType="stick"):
    """ To produce an OpenGL view of a residue. 

    - viewType = "stick" (default type of view)
               | "stick and ball"
               | "empirical"
               | "calculated"
               | "van der Waals"
               | "covalent"

    The various radiuses of the ball model of atoms are imported from
    "atomic_radius.py"; the sphere and cylinder shapes from "sphere18x27.obj"
    and "cylinder4x27.obj", respectively.
    """
    edges = graph2edges(nodes,arcs)

    def transformSphere(batchSphere,node,atom_code,viewType):
        RADIUS_TYPE = 1
        if viewType == "empirical": RADIUS_TYPE = 1
        elif viewType == "calculated": RADIUS_TYPE = 2
        elif viewType == "van der Waals": RADIUS_TYPE = 3
        elif viewType == "covalent": RADIUS_TYPE = 4
        sx = atomic_radius[atom_code][RADIUS_TYPE]/100.
        if viewType == "stick": sx=0.15
        elif viewType == "stick and ball": sx=0.4
        batchSphere.matrix = Mat4f.translate(*node)*Mat4f.scale(sx,sx,sx)
        batchSphere.diffuse=atom_color[atom_code]
        return batchSphere

    def spheres():
        batches = []
        for (node,atom_code) in zip(nodes,atom_types):
            batchSphere = Batch(unitSphere)
            batches += [transformSphere(batchSphere,node,atom_code,viewType)]
        return batches

    def transfCylr(batchCylinder,arc,vect,node,atom_code):
        sx = 0.15
        def vectTransform(vect):
            qz = UNITVECT(vect)
            qx = UNITVECT(VECTPROD([ vect,[0,0,1] ]))
            qy = VECTPROD([ qz,qx ])
            Rot = TRANS([qx,qy,qz]) 
            Rot = CAT([ Rot[0]+[0.], Rot[1]+[0.], Rot[2]+[0.], [0.,0.,0.,1.] ])
            h = VECTNORM(vect)
            return h,Rot
        h,Rot = vectTransform(vect)
        batchCylinder.matrix = \
            Mat4f.translate(*node) * Mat4f(*Rot) * Mat4f.scale(sx,sx,h/2)
        batchCylinder.diffuse = atom_color[atom_code]
        return batchCylinder

    def cylinders():
        batches = spheres()
        vects = [VECTDIFF([edge[1],edge[0]]) for edge in edges]
        for (arc,vect) in zip(arcs,vects):
            batchCyl = Batch(unitCylinder)
            batches += [transfCylr(batchCyl,arc,vect,nodes[arc[0]-1],atom_types[arc[0]-1])]
            batchCyl = Batch(unitCylinder)
            batches += [transfCylr(batchCyl,arc,AA(C(PROD)(-1))(vect),nodes[arc[1]-1],atom_types[arc[1]-1])]
        graph0 = MKPOL([nodes,arcs,None])
        batches += Plasm.getBatches(graph0)
        return batches

    return cylinders()


# peptide bonds: R_{h}[2]<->R_{h+1}[0]
def peptideBonds(residues):
    nodes,atom_types = [],[]
    for residue in residues:
        if residue.get_resname() in residueTopology.keys():
            atoms = residue.get_list()
            nodes += [atoms[0].get_coord().tolist(),
                      atoms[2].get_coord().tolist()]
            atom_types += ["H","H"]
    ind = range(len(atom_types))
    def even(k): return k%2 == 0
    arcs = [pair for pair in zip(ind[1:-2],ind[2:-1]) if even(pair[0])]
    return viewStructure(nodes,atom_types,arcs,viewType="stick")


def view_protein(filename,viewType="stick and ball"):
    batches = []
    chains = myPDBParser(filename)
    for residues in chains:
        for residue in residues:
            if residue.get_resname() in residueTopology.keys():
                nodes = [atom.get_coord().tolist() for atom in residue]
                atom_types = [atom.get_id()[0] for atom in residue]
                arcs = residueTopology[residue.get_resname()]
                n = len(residue.get_list())
                arcs = [arc for arc in arcs if (arc[0]<=n and arc[1]<=n)]
                batches += viewStructure(nodes,atom_types,arcs,viewType)
            

    for chain in chains:
        batches += peptideBonds(chain)
    # organize the batch in a loose octree
    octree = Octree(batches)
    # create the viewer and run it
    viewer=GLCanvas()
    viewer.setOctree(octree)
    viewer.runLoop()

        


if __name__ == "__main__":

    # advanced molecule visualization
    global NO_CONECT
    NO_CONECT = True
    view_protein("pdb/3B52.pdb","van der Waals")
    view_protein("pdb/3WFB.pdb","van der Waals")
    view_protein("pdb/1AQU.pdb","van der Waals")
