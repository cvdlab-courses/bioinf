# -*- coding: utf-8 -*-

## This program provides OpenGL display for a PDB-CCD file.
## Author: Alberto Paoluzzi (paoluzzi@dia.uniroma3.it)
## Copyright (C) 2010 Dipartimento Informatica e Automazione,
## Università Roma Tre, Rome, Italy.

## This library is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public
## License as published by the Free Software Foundation; either
## version 2.1 of the License, or (at your option) any later version.

## This library is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.

## You should have received a copy of the GNU General Public
## License along with this library; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from pyplasm import *
from numpy import *



def myprint (string):
    print "\n" + string + " ->", eval(string)

def sphereMap((u,v)):
    return cos(u)*cos(v),cos(u)*sin(v),-sin(u)

def cylinderMap((u,v)):
    return cos(v),sin(v),u

def grid(U,V):
    def grid0(n,m):
        return [(u,v) for u in linspace(U[0],U[1],n)
                for v in linspace(V[0],V[1],m)]
    return grid0

def sphereTriangles(n,m):
    vertTriple = [[(i+1,j+1),(i,j+1),(i,j)] for i in range(1,n-1)
                 for j in range(0,m-1)] + [
                     [(i+1,j),(i+1,j+1),(i,j)] for i in range(0,n-2)
                 for j in range(0,m-1)]
    return [[m*p[0]+p[1]+1  for p in t] for t in vertTriple]

def cylinderTriangles(n,m):
    vertTriple = [[(i+1,j+1),(i,j+1),(i,j)] for i in range(0,n-1)
                 for j in range(0,m-1)] + [
                     [(i+1,j),(i+1,j+1),(i,j)] for i in range(0,n-1)
                 for j in range(0,m-1)]
    return [[m*p[0]+p[1]+1  for p in t] for t in vertTriple]

def sphere_obj(n,m,filename):
    verts = AA(sphereMap)(sphereGrid)
    cells = sphereTriangles(n,m)
    # write head comment record
    obj = open(filename,'w')
    obj.write("# sphere model " + str(n) + " x " + str(m) + "\n")
    # write vertex records
    for v in verts:
        obj.write("v "+ str(v[0])+" "+str(v[1])+" "+str(v[2])+ "\n")
    # write normal vector records
    offset = n*m
    for v in verts:
        obj.write("vn "+ str(v[0])+" "+str(v[1])+" "+str(v[2])+ "\n")
    # write triangle records
    for t in cells:
        record = "f"
        for k in [0,1,2]: record += " "+str(t[k])+"//"+str(t[k])
        obj.write(record + "\n")
    obj.close()


def cylinder_obj(n,m,filename):
    verts = AA(cylinderMap)(cylinderGrid)
    cells = cylinderTriangles(n,m)
    # write head comment record
    obj = open(filename,'w')
    obj.write("# cylinder model " + str(n) + " x " + str(m) + "\n")
    # write vertex records
    for v in verts:
        obj.write("v "+ str(v[0])+" "+str(v[1])+" "+str(v[2])+ "\n")
    # write normal vector records
    offset = n*m
    for v in verts:
        obj.write("vn "+ str(v[0])+" "+str(v[1])+" "+str(0)+ "\n")
    # write triangle records
    for t in cells:
        record = "f"
        for k in [0,1,2]: record += " "+str(t[k])+"//"+str(t[k])
        obj.write(record + "\n")
    obj.close()

if __name__ == "__main__":

    n,m = 12,24
    
    sphereGrid = grid((-pi/2,pi/2),(-pi,pi))(n,m)
    myprint("sphereGrid")
    
    cylinderGrid = grid((0,1),(-pi,pi))(4,m)
    myprint("cylinderGrid")

    VIEW(SKELETON(1)
         (MKPOL([AA(sphereMap)(sphereGrid),sphereTriangles(n,m),[]])))

    # generate an .obj file
    sphere_obj(18,27,"sphere"+str(n)+"x"+str(m)+".obj")

    n,m = 4,24
    VIEW(SKELETON(1)
         (MKPOL([AA(cylinderMap)(cylinderGrid),cylinderTriangles(n,m),[]])))

    # generate an .obj file
    cylinder_obj(4,27,"cylinder"+str(n)+"x"+str(m)+".obj")
